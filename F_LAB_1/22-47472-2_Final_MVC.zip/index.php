<?php
header("Location: Views/Login.php");
exit();
?>
